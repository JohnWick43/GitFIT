package com.example.gitfit;

import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;import android.graphics.Color;
import android.os.Bundle;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    // creating a variable
    // for our graph view.
    GraphView graphView;
    PieChart pieChart;
    PieData pieData;
    PieDataSet pieDataSet;
    ArrayList pieEntries;
    ArrayList PieEntryLabels;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.fragment_workout);
        setContentView(R.layout.activity_main);
        /*setContentView(R.layout.fragment_diet);
        pieChart = findViewById(R.id.pieChart);*/
        //getGraphView();
        //getPieEntries();
    }

    public GraphView getGraphView() {
        setContentView(R.layout.fragment_workout);
        graphView = findViewById(R.id.idGraphView);


        // on below line we are adding data to our graph view.
        LineGraphSeries<DataPoint> series = new LineGraphSeries<DataPoint>(new DataPoint[]{
                // on below line we are adding
                // each point on our x and y axis.
                new DataPoint(0, 1),
                new DataPoint(1, 3),
                new DataPoint(2, 4),
                new DataPoint(3, 9),
                new DataPoint(4, 6),
                new DataPoint(5, 3),
                new DataPoint(6, 6),
                new DataPoint(7, 1),
                new DataPoint(8, 2)
        });
        // after adding data to our line graph series.
        // on below line we are setting
        // title for our graph view.
        graphView.setTitle("Workout Tracker");

        // on below line we are setting
        // text color to our graph view.
        graphView.setTitleColor(R.color.line_graph);

        // on below line we are setting
        // our title text size.
        graphView.setTitleTextSize(20);

        // on below line we are adding
        // data series to our graph view.
        graphView.addSeries(series);


        graphView.getGridLabelRenderer().setVerticalAxisTitle(getApplicationContext().getString(R.string.Weight_Lifted));
        graphView.getGridLabelRenderer().setHorizontalAxisTitle(getApplicationContext().getString(R.string.Time));
        graphView.getGridLabelRenderer().setVerticalLabelsColor(Color.BLACK);
        graphView.getGridLabelRenderer().setVerticalAxisTitleColor(Color.BLACK);
        graphView.getViewport().setBackgroundColor(Color.BLACK);


        return graphView;


    }

    public ArrayList getPieEntries() {
        setContentView(R.layout.fragment_diet);
        pieChart = findViewById(R.id.pieChart);
        pieEntries = new ArrayList<>();
        pieEntries.add(new PieEntry(2f, 0));
        pieEntries.add(new PieEntry(4f, 1));
        pieEntries.add(new PieEntry(6f, 2));
        pieEntries.add(new PieEntry(8f, 3));
        pieEntries.add(new PieEntry(7f, 4));
        pieEntries.add(new PieEntry(3f, 5));

        pieDataSet = new PieDataSet(pieEntries, "");
        pieData = new PieData(pieDataSet);
        pieChart.setData(pieData);
        pieDataSet.setColors(ColorTemplate.JOYFUL_COLORS);
        pieDataSet.setSliceSpace(2f);
        pieDataSet.setValueTextColor(Color.WHITE);
        pieDataSet.setValueTextSize(10f);
        pieDataSet.setSliceSpace(5f);

        return pieEntries;
    }
}